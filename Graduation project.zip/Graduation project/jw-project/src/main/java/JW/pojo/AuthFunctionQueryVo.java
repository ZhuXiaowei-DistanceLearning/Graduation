package JW.pojo;

import java.util.List;

public class AuthFunctionQueryVo {
	List<AuthFunction> list;
}
