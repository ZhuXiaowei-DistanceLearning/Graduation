package JW.pojo;

import java.util.List;

public class TScore extends TScoreKey {
	private String peaceTime;

	private String endTime;

	private String score;

	private TStudent students;

	private TCourse course;

	public String getPeaceTime() {
		return peaceTime;
	}

	public void setPeaceTime(String peaceTime) {
		this.peaceTime = peaceTime;
	}

	public String getEndTime() {
		return endTime;
	}

	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}

	public String getScore() {
		return score;
	}

	public void setScore(String score) {
		this.score = score == null ? null : score.trim();
	}

	public TStudent getStudents() {
		return students;
	}

	public void setStudents(TStudent students) {
		this.students = students;
	}

	public TCourse getCourse() {
		return course;
	}

	public void setCourse(TCourse course) {
		this.course = course;
	}

}