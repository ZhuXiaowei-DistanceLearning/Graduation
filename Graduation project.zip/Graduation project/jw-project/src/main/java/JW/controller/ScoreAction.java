package JW.controller;

import org.apache.shiro.SecurityUtils;
import org.apache.shiro.subject.Subject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.http.HttpRequest;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import JW.pojo.TCourse;
import JW.pojo.TScore;
import JW.pojo.TStudent;
import JW.service.CourseService;
import JW.service.ScoreService;
import pojo.EasyUIDataGridResult;
import utils.E3Result;

import java.io.IOException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

/**
 * Created by Administrator on 2017/6/18.
 */
@Controller
@RequestMapping("/score")
public class ScoreAction {

	@Autowired
	private ScoreService scoreService;
	@Autowired
	private CourseService courseService;

	@RequestMapping("/save")
	public String save(String ids, Integer people) {
		Subject subject = SecurityUtils.getSubject();
		TStudent student = (TStudent) subject.getPrincipal();
		TScore score = new TScore();
		score.setStudentId(student.getSid());
		score.setCourseId(ids);
		scoreService.save(score);
		int i = people + 1;
		courseService.addPeople(i, ids);
		return "/student/course";

	}

	@RequestMapping("/findStudent")
	@ResponseBody
	public List<TScore> findStudent(String studentId) throws IOException {
		List<TScore> list = scoreService.findStudent(studentId);
		return list;
	}

	@RequestMapping("/findTeacherCourseStudent")
	@ResponseBody
	public EasyUIDataGridResult findTeacherCourseStudent(Integer page, Integer rows, HttpSession session)
			throws IOException {
		TCourse course = (TCourse) session.getAttribute("addStudentScore");
		EasyUIDataGridResult result = scoreService.addScore(page, rows, course.getId());
		return result;
	}

	@RequestMapping("/addStudentScore")
	public String addStudentScore(TScore score) {
		String peaceTime = score.getPeacetime();
		String endTime = score.getEndtime();
		if (peaceTime.equals("A+") && endTime.equals("A+")) {
			score.setScore("A+");
		} else if (peaceTime.equals("A") && endTime.equals("A")) {
			score.setScore("A");
		} else if (peaceTime.equals("B+") && endTime.equals("B+")) {
			score.setScore("B+");
		} else if (peaceTime.equals("B") && endTime.equals("B")) {
			score.setScore("B");
		} else if (peaceTime.equals("C+") && endTime.equals("C+")) {
			score.setScore("C+");
		} else if (peaceTime.equals("C") && endTime.equals("C")) {
			score.setScore("C");
		} else if (peaceTime.equals("D+") && endTime.equals("D+")) {
			score.setScore("D");
		} else if (peaceTime.equals("D") && endTime.equals("D")) {
			score.setScore("D");
		} else if (peaceTime.equals("F") && endTime.equals("F")) {
			score.setScore("F");
		} else if (peaceTime.equals("F") && endTime.equals("A")) {
			score.setScore("F");
		}
		scoreService.saveScore(score);
		return "/teacher/course";
	}

	@RequestMapping("/findIdExist")
	@ResponseBody
	public String findIdExist(HttpSession session, String ids) throws IOException {
		TStudent student = (TStudent) session.getAttribute("student");
		String flag = "0";
		List<TScore> exit = scoreService.findStudentExit(student.getSid(), ids);
		if (exit.size() == 0) {
			return flag;
		} else {
			flag = "1";
			return flag;
		}
	}

	@RequestMapping("/findAllCourseByStudentId")
	public String findAllCourseByStudentId(HttpServletRequest request) {
		Subject subject = SecurityUtils.getSubject();
		TStudent student = (TStudent) subject.getPrincipal();
		List<TScore> list = scoreService.findAllCourseByStudentId(student.getSid());
		request.setAttribute("allCourse", list);
		return "forward:/score/schedulePage.action";
	}

	@RequestMapping("/schedulePage")
	public String schedulePage() {
		return "/student/schedule";
	}

	@RequestMapping("/findStudentScore")
	@ResponseBody
	public List<TScore> findStudentScore() {
		Subject subject = SecurityUtils.getSubject();
		TStudent student = (TStudent) subject.getPrincipal();
		List<TScore> list = scoreService.findStudentScore(student.getSid());
		return list;
	}

	@RequestMapping("/addAbsent")
	public String addAbsent(String[] lateStudentId,String cid){
		scoreService.addAbsent(lateStudentId,cid);
		return "forward:/student/addStudentAbsent.action?lateStudentId="+lateStudentId;
	}
}
