package JW.controller;

import org.apache.commons.fileupload.disk.DiskFileItem;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.shiro.SecurityUtils;
import org.apache.shiro.subject.Subject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.commons.CommonsMultipartFile;

import JW.pojo.AuthRole;
import JW.pojo.StudentRoleKey;
import JW.pojo.TClasses;
import JW.pojo.TStudent;
import JW.service.StudentService;
import net.sf.json.JSONArray;
import net.sf.json.JsonConfig;
import pojo.EasyUIDataGridResult;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Created by Administrator on 2017/6/17.
 */
@Controller
@RequestMapping("/student")
public class StudentAction {

	@Autowired
	private StudentService studentService;

	@RequestMapping("/importXls")
	@ResponseBody
	public String importXls(MultipartFile myFile, HttpSession session, HttpServletResponse response) throws Exception {
		String classesid = (String) session.getAttribute("classes_id");
		String flag = "1";
		try {
			XSSFWorkbook workbook = new XSSFWorkbook(myFile.getInputStream());
			XSSFSheet sheet = workbook.getSheetAt(0);
			System.out.println(sheet.getLastRowNum());
			List<TStudent> list = new ArrayList<TStudent>();
			List<StudentRoleKey> key = new ArrayList<StudentRoleKey>();
			for (Row row : sheet) {
				int rowNum = row.getRowNum();
				if (rowNum == 0) {
					continue;
				}
				XSSFCell cell = (XSSFCell) row.getCell(0);
				cell.setCellType(XSSFCell.CELL_TYPE_STRING);
				String sid = cell.getStringCellValue();
				String sname = row.getCell(1).getStringCellValue();
				String sex = row.getCell(2).getStringCellValue();
				String scity = row.getCell(3).getStringCellValue();
				String qx = "学生";
				String password = "0000";
				TStudent student = new TStudent(sid, password, sname, sex, scity, qx, classesid, 0, 0);
				String roleId = "b762e0f84ec911e8bf5d34de1af4e65a";
				list.add(student);
				StudentRoleKey srk = new StudentRoleKey();
				srk.setRoleId(roleId);
				srk.setStudentId(sid);
				key.add(srk);
			}
			studentService.saveBatch(list);
			studentService.saveSRK(key);
		} catch (Exception e) {
			System.out.println(e.getMessage());
			flag = "0";
		}
		return flag;
	}

	@RequestMapping("/pageQuery")
	@ResponseBody
	public EasyUIDataGridResult pageQuery(Integer page, Integer rows) throws IOException {
		EasyUIDataGridResult result = studentService.pageQuery(page, rows);
		return result;
	}

	@RequestMapping("/listajax")
	@ResponseBody
	public String listajax() throws IOException {
		/*
		 * List<Student> students = studentService.findAll();
		 * this.writeList2Json(students, new String[]{"scores", "classes",
		 * "roles"}); return NONE;
		 */
		return null;
	}

	@RequestMapping("/findStudentByclass")
	@ResponseBody
	public EasyUIDataGridResult findStudentByclass(Integer page, Integer rows, HttpSession session) throws IOException {
		String id = (String) session.getAttribute("classes_id");
		EasyUIDataGridResult result = studentService.findStudentByclass(id, page, rows);
		return result;
	}

	@RequestMapping("/addAbsent")
	public String addAbsent(String[] studentIds) {
		studentService.addStudentAbenst(studentIds);
		return "/teacher/course";
	}

	@RequestMapping("/addLate")
	public String addLate(String[] studentIds) {
		studentService.addStudentaddLate(studentIds);
		return "/teacher/course";
	}

	@RequestMapping("/PersonScorePage")
	public String PersonScorePage(HttpServletRequest request) {
		Subject subject = SecurityUtils.getSubject();
		TStudent student = (TStudent) subject.getPrincipal();
		request.setAttribute("PersonStudent", student);
		return "/student/PersonScore";
	}
}
