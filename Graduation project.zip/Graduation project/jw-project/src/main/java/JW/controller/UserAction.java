package JW.controller;

import org.apache.commons.lang3.StringUtils;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;

import java.io.IOException;

/**
 * Created by Administrator on 2017/6/16.
 */
@Controller
@Scope("prototype")
public class UserAction {

    public String editPassword() throws IOException {
       /* User user = (User) ServletActionContext.getRequest().getSession().getAttribute("user");
        String flag = "1";
        try {
            userService.editPassword(model.getPassword(), user.getId());
        } catch (Exception e) {
            flag = "0";
        }
        ServletActionContext.getResponse().setContentType("text/html;charset=utf-8");
        ServletActionContext.getResponse().getWriter().print(flag);
        return NONE;*/
    	return null;
    }

    public String pageQuery() throws IOException {
       /* teacherService.pageQuery(pageBean);
        this.writePageBean2Json(pageBean, new String[]{"noticebills", "roles"});
        return NONE;*/
    	return null;
    }

    private String[] roleIds;

    /**
     * 添加用户
     */
    public String add() {
       /* userService.save(model, roleIds);
        return "list";*/
    	return null;
    }


    public String[] getRoleIds() {
        return roleIds;
    }

    public void setRoleIds(String[] roleIds) {
        this.roleIds = roleIds;
    }
}
