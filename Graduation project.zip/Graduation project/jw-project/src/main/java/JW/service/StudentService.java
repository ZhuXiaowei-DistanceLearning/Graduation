package JW.service;

import java.util.List;

import JW.pojo.StudentRoleKey;
import JW.pojo.TStudent;
import pojo.EasyUIDataGridResult;

/**
 * Created by Administrator on 2017/6/17.
 */
public interface StudentService {
	public void saveBatch(List<TStudent> student);

	public List<TStudent> findAll();

	public TStudent findByUsername(String username);

	public EasyUIDataGridResult findStudentByclass(String ids, Integer page, Integer rows);

	public EasyUIDataGridResult pageQuery(Integer page, Integer rows);

	public void saveSRK(List<StudentRoleKey> key);

	public void addStudentAbenst(String[] studentIds);

	public void addStudentaddLate(String[] studentIds);

}
