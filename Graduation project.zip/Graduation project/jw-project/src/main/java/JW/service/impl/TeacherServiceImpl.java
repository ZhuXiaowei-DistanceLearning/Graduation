package JW.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;

import JW.mapper.TTeacherMapper;
import JW.mapper.TeacherRoleMapper;
import JW.pojo.TTeacher;
import JW.pojo.TTeacherExample;
import JW.pojo.TUser;
import JW.pojo.TUserExample;
import JW.pojo.TUserExample.Criteria;
import JW.pojo.TeacherRoleKey;
import JW.service.TeacherService;
import pojo.EasyUIDataGridResult;

import java.util.List;

/**
 * Created by Administrator on 2017/6/18.
 */
@Service
public class TeacherServiceImpl implements TeacherService {
	@Autowired
	private TTeacherMapper teacherMapper;
	@Autowired
	private TeacherRoleMapper teacherRoleMapper;

	@Override
	public List<TTeacher> findListNoStatus() {
		TTeacherExample example = new TTeacherExample();
		example.createCriteria().andStatusEqualTo("0");
		List<TTeacher> list = teacherMapper.selectByExample(example);
		return list;
	}

	/*
	 * @Autowired private TeacherDao teacherDao;
	 * 
	 * @Override public void pageQuery(PageBean pageBean) {
	 * teacherDao.pageQuery(pageBean); }
	 * 
	 * @Override public List<Teacher> findListNoStatus() { DetachedCriteria
	 * detachedCriteria = DetachedCriteria.forClass(Teacher.class);
	 * detachedCriteria.add(Restrictions.ne("status", "1")); return
	 * teacherDao.findByCriteria(detachedCriteria); }
	 * 
	 * @Override public void save(Teacher model, String[] roleIds) {
	 * teacherDao.save(model); for (String id : roleIds) { Role role = new
	 * Role(id); model.getRoles().add(role); } }
	 */

	@Override
	public TTeacher findByUsername(String username) {
		TTeacherExample teacherExample = new TTeacherExample();
		JW.pojo.TTeacherExample.Criteria teacherCriteria = teacherExample.createCriteria();
		teacherCriteria.andTidEqualTo(username);
		List<TTeacher> teacher = teacherMapper.selectByExample(teacherExample);
		if (teacher.size() == 1) {
			return teacher.get(0);
		} else {
			return null;
		}
	}

	@Override
	public EasyUIDataGridResult pageQuery(Integer page, Integer rows) {
		PageHelper.startPage(page, rows);
		List<TTeacher> list = teacherMapper.findAll();
		EasyUIDataGridResult result = new EasyUIDataGridResult();
		result.setRows(list);
		PageInfo<TTeacher> info = new PageInfo<>(list);
		result.setTotal(info.getTotal());
		return result;
	}

	@Override
	public void save(TTeacher model, String roleIds) {
		teacherMapper.insert(model);
		String[] ids = roleIds.split(",");
		for (String id : ids) {
			TeacherRoleKey record = new TeacherRoleKey();
			record.setRoleId(id);
			record.setTeacherId(model.getTid());
			teacherRoleMapper.insert(record);
		}
	}
}
