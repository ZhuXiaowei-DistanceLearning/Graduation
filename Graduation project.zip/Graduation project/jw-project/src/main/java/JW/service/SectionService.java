package JW.service;


import java.util.List;

import JW.pojo.TSection;

/**
 * Created by Administrator on 2017/6/18.
 */
public interface SectionService {
    public List<TSection> findAll();
}
