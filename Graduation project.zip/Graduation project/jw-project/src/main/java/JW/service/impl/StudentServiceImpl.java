package JW.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;

import JW.mapper.StudentRoleMapper;
import JW.mapper.TStudentMapper;
import JW.pojo.StudentRoleKey;
import JW.pojo.TStudent;
import JW.pojo.TStudentExample;
import JW.pojo.TStudentExample.Criteria;
import JW.service.StudentService;
import pojo.EasyUIDataGridResult;
import utils.E3Result;

import java.util.List;

/**
 * Created by Administrator on 2017/6/17.
 */
@Service
public class StudentServiceImpl implements StudentService {
	@Autowired
	private TStudentMapper studentMapper;
	@Autowired
	private StudentRoleMapper studentRoleKeyMapper;

	@Override
	public void saveBatch(List<TStudent> student) {
		for (TStudent model : student) {
			studentMapper.insert(model);
		}
	}

	@Override
	public List<TStudent> findAll() {
		return null;
	}

	/*
	 * @Autowired private StudentDao studentDao;
	 * 
	 * @Override public void saveBatch(List<Student> student) { for (Student
	 * model : student) { studentDao.saveOrUpdate(model); } }
	 * 
	 * @Override public void pageQuery(PageBean pageBean) {
	 * studentDao.pageQuery(pageBean); }
	 * 
	 * @Override public List<Student> findAll() { return studentDao.findAll(); }
	 * 
	 * @Override public List<Student> findStudentById(PageBean pageBean, String
	 * id) { return studentDao.findStudentById(pageBean, id); }
	 * 
	 * @Override public void addStudentAbenst(Integer absent, String[]
	 * studentIds) { for (String id : studentIds) { Student student =
	 * studentDao.findById(id); int i = student.getAbsent(); absent = i + 2;
	 * studentDao.executeUpdate("student.absent", absent, id); } }
	 */

	@Override
	public TStudent findByUsername(String username) {
		TStudentExample studentExample = new TStudentExample();
		JW.pojo.TStudentExample.Criteria studentCriteria = studentExample.createCriteria();
		studentCriteria.andSidEqualTo(username);
		List<TStudent> student = studentMapper.selectByExample(studentExample);
		if (student.size() == 1) {
			return student.get(0);
		} else {
			return null;
		}
	}

	@Override
	public EasyUIDataGridResult findStudentByclass(String ids, Integer page, Integer rows) {
		PageHelper.startPage(page, rows);
		List<TStudent> list = studentMapper.findAll(ids);
		EasyUIDataGridResult result = new EasyUIDataGridResult();
		result.setRows(list);
		PageInfo<TStudent> pageInfo = new PageInfo<>(list);
		long total = pageInfo.getTotal();
		result.setTotal(total);
		return result;
	}

	@Override
	public EasyUIDataGridResult pageQuery(Integer page, Integer rows) {
		return null;
	}

	@Override
	public void saveSRK(List<StudentRoleKey> key) {
		for (StudentRoleKey record : key) {
			studentRoleKeyMapper.insert(record);
		}
	}

	@Override
	public void addStudentAbenst(String[] studentIds) {
		for (String id : studentIds) {
			TStudentExample example = new TStudentExample();
			example.createCriteria().andSidEqualTo(id);
			List<TStudent> list = studentMapper.selectByExample(example);
			TStudent student = list.get(0);
			int i = student.getAbsent();
			TStudent record = new TStudent();
			record.setSid(student.getSid());
			record.setAbsent(i + 1);
			studentMapper.updateByPrimaryKeySelective(record);
		}
	}

	@Override
	public void addStudentaddLate(String[] studentIds) {
		for (String id : studentIds) {
			TStudentExample example = new TStudentExample();
			example.createCriteria().andSidEqualTo(id);
			List<TStudent> list = studentMapper.selectByExample(example);
			TStudent student = list.get(0);
			int i = student.getAbsent();
			TStudent record = new TStudent();
			record.setSid(student.getSid());
			record.setLate(i + 1);
			studentMapper.updateByPrimaryKeySelective(record);
		}
	}
}