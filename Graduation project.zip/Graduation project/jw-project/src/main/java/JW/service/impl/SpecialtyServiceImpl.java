package JW.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.Model;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;

import JW.mapper.TSpecialtyMapper;
import JW.pojo.TSpecialty;
import JW.pojo.TSpecialtyExample;
import JW.pojo.TSpecialtyExample.Criteria;
import JW.service.SpecialtyService;
import pojo.EasyUIDataGridResult;

import java.util.List;

/**
 * Created by Administrator on 2017/6/17.
 */
@Service
public class SpecialtyServiceImpl implements SpecialtyService {

	@Autowired
	private TSpecialtyMapper specialtyMapper;

	@Override
	public void add(TSpecialty model) {
		specialtyMapper.insert(model);
	}

	@Override
	public void update(TSpecialty model) {
		specialtyMapper.updateByPrimaryKey(model);
	}

	@Override
	public void deleteBatch(String ids) {
		String[] id = ids.split(",");
		for (String spId : id) {
			specialtyMapper.deleteBatch(spId);
		}
	}

	@Override
	public List<TSpecialty> listajax() {
		TSpecialtyExample example = new TSpecialtyExample();
		List<TSpecialty> list = specialtyMapper.selectByExample(example);
		return list;
	}
	/*
	 * @Autowired private SpecialtyDao specialtyDao;
	 * 
	 * @Override public void add(Specialty model) { specialtyDao.save(model); }
	 * 
	 * @Override public void pageQuery(PageBean pageBean) {
	 * this.specialtyDao.pageQuery(pageBean); }
	 * 
	 * @Override public void update(Specialty model) {
	 * specialtyDao.update(model); }
	 * 
	 * @Override public void deleteBatch(String id) { String[] split =
	 * id.split(","); for (String ids : split) {
	 * specialtyDao.executeUpdate("specialty.delete", ids); } }
	 * 
	 * @Override public List<Specialty> listajax() { DetachedCriteria
	 * detachedCriteria = DetachedCriteria.forClass(Specialty.class);
	 * detachedCriteria.add(Restrictions.ne("status", "1")); return
	 * specialtyDao.findByCriteria(detachedCriteria); }
	 */

	@Override
	public EasyUIDataGridResult pageQuery(int page, int rows) {
		PageHelper.startPage(page, rows);
		List<TSpecialty> list = specialtyMapper.findAll();
		EasyUIDataGridResult result = new EasyUIDataGridResult();
		result.setRows(list);
		PageInfo<TSpecialty> pageInfo = new PageInfo<>(list);
		long total = pageInfo.getTotal();
		result.setTotal(total);
		return result;
	}

}
