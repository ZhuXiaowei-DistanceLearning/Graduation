package JW.pojo;

public class TScore extends TScoreKey {
    private String peacetime;

    private String endtime;

    private String score;

    private String absent;

    public String getPeacetime() {
        return peacetime;
    }

    public void setPeacetime(String peacetime) {
        this.peacetime = peacetime == null ? null : peacetime.trim();
    }

    public String getEndtime() {
        return endtime;
    }

    public void setEndtime(String endtime) {
        this.endtime = endtime == null ? null : endtime.trim();
    }

    public String getScore() {
        return score;
    }

    public void setScore(String score) {
        this.score = score == null ? null : score.trim();
    }

    public String getAbsent() {
        return absent;
    }

    public void setAbsent(String absent) {
        this.absent = absent == null ? null : absent.trim();
    }
}