package JW.listener;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpSessionBindingEvent;
import javax.servlet.http.HttpSessionEvent;
import javax.servlet.http.HttpSessionListener;

public class SessionListener implements HttpSessionListener {
	public static int count;

	@Override
	public void sessionCreated(HttpSessionEvent se) {
		count++;
		System.out.println("当前在线人数:" + count);
		/*
		 * int i = 0; ServletContext context =
		 * se.getSession().getServletContext(); Object object =
		 * context.getAttribute("object");
		 * se.getSession().setMaxInactiveInterval(60); if (object == null) {
		 * System.out.println("用户为空"); } else { i += 1; }
		 * se.getSession().setAttribute("visitPeople", i);
		 */
	}

	@Override
	public void sessionDestroyed(HttpSessionEvent se) {
		count--;
		System.out.println("当前在线人数:" + count);
		/*
		 * ServletContext context = se.getSession().getServletContext(); Object
		 * object = context.getAttribute("obj"); if (object == null) { int i =
		 * (int) context.getAttribute("visitPeople"); i -= 1;
		 * se.getSession().setAttribute("visitPeople", i); } else {
		 * System.out.println("释放了"); }
		 */
	}

	public static int getCount() {
		return count;
	}
}
