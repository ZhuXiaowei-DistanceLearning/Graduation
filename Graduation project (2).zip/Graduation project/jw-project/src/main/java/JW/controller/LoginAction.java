package JW.controller;

import java.io.IOException;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang3.StringUtils;
import org.apache.shiro.SecurityUtils;
import org.apache.shiro.authc.AuthenticationToken;
import org.apache.shiro.authc.UnknownAccountException;
import org.apache.shiro.authc.UsernamePasswordToken;
import org.apache.shiro.subject.Subject;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import JW.listener.SessionListener;
import JW.pojo.TStudent;
import JW.pojo.TTeacher;
import JW.pojo.TUser;
import utils.CookieUtils;
import utils.E3Result;

/**
 * Created by Administrator on 2017/6/19.
 */
@Controller
public class LoginAction {

	@Value("${TOKEN_KEY}")
	private String TOKEN_KEY;

	@RequestMapping("/home.action")
	@ResponseBody
	public E3Result login(String username, String password, String checkcode, String RadioButtonList1,
			HttpSession session, HttpServletResponse response) {
		String key = (String) session.getAttribute("key");
		if (StringUtils.isNotBlank(checkcode) && checkcode.equals(key)) {
			Subject subject = SecurityUtils.getSubject();
			AuthenticationToken token = new UsernamePasswordToken(username, password);
			try {
				subject.login(token);
			} catch (UnknownAccountException e) {
				e.printStackTrace();
				return E3Result.build(101, "用户名不存在");
			} catch (Exception e) {
				e.printStackTrace();
				return E3Result.build(114, "用户名或密码错误!");
			}
			Object user = subject.getPrincipal();
			boolean permittedAll = subject.isPermittedAll();
			if (RadioButtonList1.equals("访客")) {
				if (user instanceof TUser) {
					if (user != null) {
						return E3Result.ok(200);
					} else {
						return E3Result.build(114, "用户名或密码错误!");
					}
				} else {
					return E3Result.build(101, "用户名不存在");
				}
			} else if (RadioButtonList1.equals("教师")) {
				if (user instanceof TTeacher) {
					if (user != null) {
						return E3Result.ok(200);
					} else {
						return E3Result.build(114, "用户名或密码错误!");
					}
				} else {
					return E3Result.build(101, "用户名不存在");
				}
			} else if (RadioButtonList1.equals("学生")) {
				if (user instanceof TStudent) {
					if (user != null) {
						return E3Result.ok(200);
					} else {
						return E3Result.build(114, "用户名或密码错误!");
					}
				} else {
					return E3Result.build(101, "用户名不存在");
				}
			}
		} else {
			return E3Result.build(102, "验证码错误!");
		}
		return null;
	}

	@RequestMapping("index")
	public String pageIndex(HttpServletRequest request, HttpServletResponse response, HttpSession session) {
		TUser user = (TUser) session.getAttribute("user");
		TTeacher teacher = (TTeacher) session.getAttribute("teacher");
		TStudent student = (TStudent) session.getAttribute("student");
		String Cookietoken = UUID.randomUUID().toString();
		if (user != null) {
			user.setPassword(null);
			CookieUtils.setCookie(request, response, TOKEN_KEY, Cookietoken);
		} else if (teacher != null) {
			teacher.setPassword(null);
			CookieUtils.setCookie(request, response, TOKEN_KEY, Cookietoken);
		} else if (student != null) {
			student.setPassword(null);
			CookieUtils.setCookie(request, response, TOKEN_KEY, Cookietoken);
		}
		return "/common/index";
	}

	@RequestMapping("logout")
	public E3Result logout(HttpSession session) {
		session.invalidate();
		return E3Result.ok(200);
	}
}
