package JW.controller;

import org.apache.shiro.SecurityUtils;
import org.apache.shiro.subject.Subject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import JW.pojo.TStudent;
import JW.service.StudentService;
import net.sf.json.JSONArray;
import net.sf.json.JsonConfig;
import pojo.EasyUIDataGridResult;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

/**
 * Created by Administrator on 2017/6/17.
 */
@Controller
@RequestMapping("/student")
public class StudentAction {

	@Autowired
	private StudentService studentService;

	public String importXls(File myFile) throws Exception {
		/*
		 * Classes classes = (Classes)
		 * ServletActionContext.getRequest().getSession().getAttribute(
		 * "classes_id"); String flag = "1"; try { //获取HSSFWorkbook对象
		 * HSSFWorkbook workbook = new HSSFWorkbook(new
		 * FileInputStream(myFile)); //getSheetAt，获取HSSFSheet HSSFSheet sheet =
		 * workbook.getSheetAt(0); System.out.println(sheet.getLastRowNum());
		 * List<Student> list = new ArrayList<Student>(); //Row接收HSSFSheet对象的值
		 * for (Row row : sheet) { int rowNum = row.getRowNum(); if (rowNum ==
		 * 0) { continue; } HSSFCell cell = (HSSFCell) row.getCell(0);
		 * cell.setCellType(HSSFCell.CELL_TYPE_STRING); String sid =
		 * cell.getStringCellValue(); HSSFCell cell2 = (HSSFCell)
		 * row.getCell(1); cell2.setCellType(HSSFCell.CELL_TYPE_STRING); String
		 * password = cell2.getStringCellValue(); String sname =
		 * row.getCell(2).getStringCellValue(); String sex =
		 * row.getCell(3).getStringCellValue(); String scity =
		 * row.getCell(4).getStringCellValue(); String qx = "学生"; Student
		 * student = new Student(sid, password, sname, sex, scity, qx, classes,
		 * null); String roleId = "8a6ebaad5cbf6d3b015cbfa6e5430002";
		 * list.add(student); Role role = new Role(roleId);
		 * student.getRoles().add(role); } studentService.saveBatch(list); }
		 * catch (Exception e) { flag = "0"; }
		 * ServletActionContext.getResponse().setContentType(
		 * "text/json;charset=utf-8");
		 * ServletActionContext.getResponse().getWriter().print(flag); return
		 * "studentInfo";
		 */
		return null;
	}

	@RequestMapping("/pageQuery")
	@ResponseBody
	public EasyUIDataGridResult pageQuery(Integer page, Integer rows) throws IOException {
		EasyUIDataGridResult result = studentService.pageQuery(page, rows);
		return null;
	}

	@RequestMapping("/listajax")
	@ResponseBody
	public String listajax() throws IOException {
		/*
		 * List<Student> students = studentService.findAll();
		 * this.writeList2Json(students, new String[]{"scores", "classes",
		 * "roles"}); return NONE;
		 */
		return null;
	}

	@RequestMapping("/findStudentByclass")
	@ResponseBody
	public EasyUIDataGridResult findStudentByclass(Integer page, Integer rows, HttpSession session) throws IOException {
		String id = (String) session.getAttribute("classes_id");
		EasyUIDataGridResult result = studentService.findStudentByclass(id, page, rows);
		return result;
	}

	@RequestMapping("/addAbsent")
	public String addAbsent() {
		/*
		 * studentService.addStudentAbenst(model.getAbsent(), studentIds);
		 * return "teacherlist";
		 */
		return null;
	}

	@RequestMapping("/PersonScorePage")
	public String PersonScorePage(HttpServletRequest request) {
		Subject subject = SecurityUtils.getSubject();
		TStudent student = (TStudent) subject.getPrincipal();
		request.setAttribute("PersonStudent", student);
		return "/student/PersonScore";
	}
}
