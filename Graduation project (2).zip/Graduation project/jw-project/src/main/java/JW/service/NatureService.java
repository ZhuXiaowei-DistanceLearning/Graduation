package JW.service;


import java.util.List;

import JW.pojo.TNature;

/**
 * Created by Administrator on 2017/6/19.
 */
public interface NatureService {
    public List<TNature> findAll();
}
