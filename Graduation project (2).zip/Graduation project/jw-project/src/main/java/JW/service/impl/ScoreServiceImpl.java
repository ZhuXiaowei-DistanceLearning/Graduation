package JW.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;

import JW.mapper.TScoreMapper;
import JW.pojo.TScore;
import JW.pojo.TScoreExample;
import JW.pojo.TStudent;
import JW.pojo.TStudentExample;
import JW.pojo.TScoreExample.Criteria;
import JW.pojo.TScoreKey;
import JW.service.ScoreService;
import pojo.EasyUIDataGridResult;

import java.util.List;

/**
 * Created by Administrator on 2017/6/20.
 */
@Service
public class ScoreServiceImpl implements ScoreService {

	@Autowired
	private TScoreMapper scoreMapper;

	/**
	 * 添加成绩
	 */
	@Override
	public void save(TScore model) {
		scoreMapper.insert(model);
	}

	@Override
	public List<TScore> findStudent(String id) {
		List<TScore> list = scoreMapper.findStudentId(id);
		return list;
	}

	@Override
	public List<TScore> findById(String studentId) {
		List<TScore> list = scoreMapper.findStudentId(studentId);
		return list;
	}

	@Override
	public void saveScore(TScore model) {
		scoreMapper.updateByPrimaryKey(model);
	}

	@Override
	public List<TScore> findAllCourseByStudentId(String sid) {
		List<TScore> list = scoreMapper.findAllCourseByStudentId(sid);
		return list;
	}

	@Override
	public EasyUIDataGridResult addScore(Integer page, Integer rows, String id) {
		PageHelper.startPage(page, rows);
		List<TScore> list = scoreMapper.addStudentScore(id);
		EasyUIDataGridResult result = new EasyUIDataGridResult();
		result.setRows(list);
		PageInfo<TScore> info = new PageInfo<>(list);
		result.setTotal(info.getTotal());
		return result;
	}

	@Override
	public List<TScore> findStudentExit(String sid, String ids) {
		List<TScore> list = scoreMapper.findCourseStudentId(sid, ids);
		return list;
	}

	@Override
	public List<TScore> findStudentScore(String sid) {
		List<TScore> list = scoreMapper.findStudentScore(sid);
		return list;
	}
}
