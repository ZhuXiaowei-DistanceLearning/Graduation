package JW.service;


import java.util.List;

import JW.pojo.TWeek;

/**
 * Created by Administrator on 2017/6/18.
 */
public interface WeekService {
    public List<TWeek> findAll();
}
